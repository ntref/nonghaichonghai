function I = color_feature(G0)
% ��ɫ������ȡ

[M0,N0] = size(G0);
G1 = G0;
if rem(M0,3) ~= 0
    if rem(M0,3) == 1
        G1(M0+1,:) = G0(M0,:);
        G1(M0+2,:) = G0(M0,:);
    elseif rem(M0,3) == 2
        G1(M0+1,:) = G0(M0,:);
    end
end
G = G1;
if rem(N0,3) ~= 0
    if rem(N0,3) == 1
        G(:,N0+1) = G1(:,N0);
        G(:,N0+2) = G1(:,N0);
    elseif rem(N0,3) == 2
        G(:,N0+1) = G1(:,N0);
    end
end
[M,N] = size(G);
k = 1;
I = 0;
for i = 1:M/3:M
    for j = 1:N/3:N
        block{k} = G(i:i+M/3-1,j:j+N/3-1);
        if k == 1
            [a,b] = size(block{k});
            N1 = a*b;
        end
        temp = [];
        temp = unique(block{k});
        num = zeros(1,72);
        for i = 1:numel(temp);
            num(temp(i)+1) = numel(find(temp(i)==block{k})); 
        end
        for ii = 0:71
            if ii == 0
                I(k,ii+1) = num(ii+1)/N1;
            else
                I(k,ii+1) = I(k,ii)+num(ii+1)/N1;
            end
        end
        k = k+1;
    end
end
